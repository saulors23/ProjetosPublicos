﻿using CadastroClientes.Core.Models;
using CadastroClientes.Core.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace CadastroClientes.Web.Controllers
{
    public class ClientesController : Controller
    {
        private readonly IClienteService _clienteService;
        private readonly ILogradouroService _logradouroService;

        public ClientesController(IClienteService clienteService, ILogradouroService logradouroService)
        {
            _clienteService = clienteService;
            _logradouroService = logradouroService;
        }

        #region Consulta todos os Clientes do Cadastro
        public async Task<IActionResult> Index()
        {
            try
            {
                var clientes = await _clienteService.GetClientes();

                return View(clientes ?? new List<Cliente>());
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "Ocorreu um erro ao carregar os clientes.";
                return View(new List<Cliente>());
            }
        }
        #endregion

        #region Consulta detalhes do cliente no Cadastro
        public async Task<IActionResult> Details(int id)
        {
            var cliente = _clienteService.GetClienteById(id);

            if (cliente == null)
            {
                return NotFound();
            }
                return View(cliente);
        }
        #endregion


        public IActionResult Create()
        {
            return View();
        }

        #region Adiciona um novo cliente no Cadastro
        [HttpPost]
        public async Task<IActionResult> Create(Cliente cliente, List<Logradouro> logradouros)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    if (await _clienteService.EmailExists(cliente.Email))
                    {
                        ViewBag.EmailExistsError = "O Email do(a) Cliente Informado já Existe no Sistema.";

                        ViewBag.IsReloadedPage = true;

                        return View(cliente);
                    }

                    await _clienteService.AddCliente(cliente);

                    foreach (var logradouro in logradouros)
                    {
                        logradouro.ClienteId = cliente.Id ?? 0; 
                        await _logradouroService.AddLogradouro(logradouro);
                    }

                    TempData["CreateSuccess"] = true;

                    return RedirectToAction("Index");
                }
                catch (Exception ex)
                {
                    ViewBag.ErrorMessage = "Ocorreu um erro ao criar o cliente.";                    
                    return View(cliente);
                }
            }
            return View(cliente);
        }
        #endregion
    }
}
