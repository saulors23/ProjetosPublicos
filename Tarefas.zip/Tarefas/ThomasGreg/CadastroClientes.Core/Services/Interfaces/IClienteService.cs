﻿using CadastroClientes.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CadastroClientes.Core.Services.Interfaces
{
    public interface IClienteService
    {
        Task<List<Cliente>> GetClientes();
        Task<Cliente> GetClienteById(int id);
        Task<bool> EmailExists(string cpf);
        Task AddCliente(Cliente cliente);
        //Task UpdateCliente(Cliente cliente);
        //Task DeleteCliente(int id);
    }
}
