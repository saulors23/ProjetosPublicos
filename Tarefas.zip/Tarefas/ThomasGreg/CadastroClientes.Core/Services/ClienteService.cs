﻿using CadastroClientes.Core.Data;
using CadastroClientes.Core.Models;
using CadastroClientes.Core.Repositories.Interfaces;
using CadastroClientes.Core.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CadastroClientes.Core.Services
{
    public class ClienteService : IClienteService
    {
        private readonly IClienteRepository _clienteRepository;
        private readonly ILogradouroRepository _logradouroRepository;
        public ClienteService(IClienteRepository clienteRepository, ILogradouroRepository logradouroRepository)
        {
            _clienteRepository = clienteRepository;
            _logradouroRepository = logradouroRepository;
        }

        #region Consulta todos os Clientes do Cadastro
        public async Task<List<Cliente>> GetClientes()
        {
            try
            {
                var listaClientes = await _clienteRepository.GetClientes();

                if (listaClientes != null && listaClientes is List<Cliente>)
                {
                    return listaClientes;
                }

                return new List<Cliente>();
            }
            catch (Exception ex)
            {
                return new List<Cliente>();
            }
        }
        #endregion

        #region Consulta detalhes do cliente no Cadastro
        public async Task<Cliente> GetClienteById(int id)
        {
            var cliente = await _clienteRepository.GetClienteById(id);

            if (cliente != null && cliente.Id.HasValue)
            {
                int clienteId = cliente.Id.Value;
                cliente.Logradouros = await _logradouroRepository.GetLogradourosByClienteId(clienteId);
            }

            return cliente;
        }
        #endregion

        #region Adiciona um Novo Cliente
        public async Task<bool> EmailExists(string email)
        {
            return await _clienteRepository.EmailExists(email);
        }
        public async Task AddCliente(Cliente cliente)
        {
            await _clienteRepository.AddCliente(cliente);
        }
        #endregion
    }
}
