﻿using CadastroClientes.Core.Data;
using CadastroClientes.Core.Models;
using CadastroClientes.Core.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CadastroClientes.Core.Repositories
{
    public class ClienteRepository : IClienteRepository
    {
        private readonly AppDbContext _dbContext;
        public ClienteRepository(AppDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        #region Lista todos os Clientes do Cadastro
        public async Task<List<Cliente>> GetClientes()
        {
            var clientes = await _dbContext.Clientes.ToListAsync();

            if (clientes == null) throw new System.Exception("Não existe registros de Clientes!");

            return clientes ?? new List<Cliente>();
        }
        #endregion

        public async Task<Cliente> GetClienteById(int id)
        {
            return await _dbContext.Clientes.FindAsync(id);
        }

        public async Task<bool> EmailExists(string email)
        {
            return await _dbContext.Clientes.AnyAsync(c => c.Email == email);
        }

        public async Task AddCliente(Cliente cliente)
        {
            if (cliente == null)
            {
                throw new ArgumentNullException(nameof(cliente));
            }

            await _dbContext.Clientes.AddAsync(cliente);
            await _dbContext.SaveChangesAsync();
        }
    }
}
