﻿using CadastroClientes.Core.Models;
using CadastroClientes.Core.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace CadastroClientes.Api.Controllers
{
    public class ClientesController : ControllerBase
    {
        private readonly IClienteService _clienteService;
        private readonly ILogradouroService _logradouroService;

        public ClientesController(IClienteService clienteService, ILogradouroService logradouroService)
        {
            _clienteService = clienteService;
            _logradouroService = logradouroService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllClientes()
        {
            try
            {
                var clientes = await _clienteService.GetClientes();

                return Ok(clientes);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Erro ao consultar clientes: {ex.Message}");
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetClienteById(int id)
        {
            try
            {
                var cliente = await _clienteService.GetClienteById(id);

                if (cliente == null)
                {
                    return NotFound();
                }

                return Ok(cliente);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Erro ao consultar cliente por ID: {ex.Message}");
            }
        }

        [HttpGet("{clienteId}/logradouros")]
        public async Task<IActionResult> GetLogradourosByClienteId(int clienteId)
        {
            try
            {
                var logradouros = await _logradouroService.GetLogradourosByClienteId(clienteId);

                if (logradouros == null || !logradouros.Any())
                {
                    return NotFound($"Nenhum logradouro encontrado para o cliente com ID {clienteId}.");
                }

                return Ok(logradouros);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Erro ao consultar logradouros para o cliente com ID {clienteId}: {ex.Message}");
            }
        }

        [HttpPost]
        public async Task<IActionResult> AddCliente(Cliente cliente)
        {
            if (ModelState.IsValid)
            {
                if (await _clienteService.EmailExists(cliente.Email))
                {
                    return Conflict("O Email do Cliente Informado já Existe no Sistema.");
                }

                await _clienteService.AddCliente(cliente);
                return Ok(cliente);
            }
            return BadRequest(ModelState);
        }

        [HttpPost("{clienteId}/logradouro")]
        public async Task<IActionResult> AddLogradouro(int clienteId, Logradouro logradouro)
        {
            try
            {
                var cliente = await _clienteService.GetClienteById(clienteId);

                if (cliente == null)
                {
                    return NotFound($"Cliente com ID {clienteId} não encontrado.");
                }

                logradouro.ClienteId = cliente.Id ?? 0; 

                await _logradouroService.AddLogradouro(logradouro);

                return Ok(logradouro);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Erro ao adicionar logradouro para o cliente com ID {clienteId}: {ex.Message}");
            }
        }
    }
}
